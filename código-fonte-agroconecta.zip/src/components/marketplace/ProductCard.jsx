// src/components/marketplace/ProductCard.jsx
import { useMemo, useState } from "react";

export default function ProductCard({
  product,
  mode, // "comprar" | "doar"
  onAddPurchase, // (productId, qty) => void
  onAddDonation, // (productId) => void
}) {
  const [qty, setQty] = useState(1);

  const photo = useMemo(() => {
    if (product?.photos?.length) return product.photos[0];
    // placeholder
    const q = encodeURIComponent(product.title || "Produto");
    return `https://placehold.co/600x400?text=${q}`;
  }, [product]);

  function inc() {
    if (product.stock == null) return;
    setQty((n) => Math.min(n + 1, product.stock));
  }
  function dec() {
    setQty((n) => Math.max(1, n - 1));
  }
  function addPurchase() {
    const validQty = Math.max(1, Math.min(qty, product.stock ?? 1));
    onAddPurchase(product.id, validQty);
    setQty(1);
  }
  function addDonation() {
    onAddDonation(product.id);
  }

  return (
    <li className="agc-card">
      {/* Imagem */}
      <div className="agc-card-img-wrap">
        <img className="agc-card-img" src={photo} alt={product.title} />
      </div>

      {/* Meta */}
      <div className="agc-meta">
        {product.category} • {product.location}
      </div>

      {/* Título */}
      <h3 className="agc-name">{product.title}</h3>

      {/* Badges */}
      <div className="agc-badges">
        {product.isUgly && (
          <span className="agc-badge agc-badge--ugly">Fora do padrão</span>
        )}
        {product.isDonation && (
          <span className="agc-badge agc-badge--donation">Doação</span>
        )}
      </div>

      {/* Conteúdo por modo */}
      {mode === "comprar" ? (
        <>
          <div className="agc-muted" style={{ marginBottom: 8 }}>
            Preço:{" "}
            <span className="agc-price">R$ {product.price?.toFixed(2)}</span>
            {product.unit ? ` / ${product.unit}` : ""}
          </div>
          <div className="agc-muted" style={{ marginBottom: 12 }}>
            Estoque: {product.stock}
          </div>

          {/* Stepper de quantidade */}
          <div className="agc-qty">
            <button className="agc-qty-btn" onClick={dec} aria-label="Diminuir">
              −
            </button>
            <input
              className="agc-qty-input"
              type="number"
              min={1}
              max={product.stock ?? undefined}
              value={qty}
              onChange={(e) => {
                const v = Number(e.target.value);
                if (Number.isNaN(v)) return;
                const max = product.stock ?? Infinity;
                setQty(Math.max(1, Math.min(v, max)));
              }}
            />
            <button className="agc-qty-btn" onClick={inc} aria-label="Aumentar">
              +
            </button>
          </div>

          <button
            className="agc-btn"
            style={{ width: "100%" }}
            onClick={addPurchase}
          >
            Adicionar
          </button>
        </>
      ) : (
        <>
          <div className="agc-muted" style={{ marginBottom: 12 }}>
            Combine a retirada diretamente com o produtor.
          </div>
          <button
            className="agc-btn"
            style={{ width: "100%" }}
            onClick={addDonation}
          >
            Solicitar
          </button>
        </>
      )}
    </li>
  );
}
